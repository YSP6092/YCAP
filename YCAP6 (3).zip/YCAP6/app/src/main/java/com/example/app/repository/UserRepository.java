package com.example.app.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {

    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // Save new user
    public void saveUser(String name, String username, String password) {
        String sql = "INSERT INTO users (name, username, password) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, name, username, password);
    }

    // Validate login credentials
    public boolean validateUser(String username, String password) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ? AND password = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, username, password);
        return count != null && count > 0;
    }

    // ✅ Update user details
    public void updateUser(String username, String name, String password) {
        String sql = "UPDATE users SET name = ?, password = ? WHERE username = ?";
        jdbcTemplate.update(sql, name, password, username);
    }
}
