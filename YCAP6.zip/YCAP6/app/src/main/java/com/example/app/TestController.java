package com.example.app;

import com.example.app.repository.UserRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class TestController {

    private final UserRepository userRepository;

    public TestController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/")
    public String home() {
        return "login";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam("username") String username,
                          @RequestParam("password") String password,
                          RedirectAttributes redirectAttributes) {

        if (userRepository.validateUser(username, password)) {
            redirectAttributes.addFlashAttribute("username", username);
            return "redirect:/welcome";
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid credentials!");
            return "redirect:/login";
        }
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }

    @PostMapping("/register")
    public String submit(@RequestParam("name") String name,
                         @RequestParam("username") String username,
                         @RequestParam("password") String password,
                         @RequestParam("confirmPassword") String confirmPassword,
                         RedirectAttributes redirectAttributes) {

        if (!password.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("error", "Passwords do not match!");
            return "redirect:/register";
        }

        userRepository.saveUser(name, username, password);

        redirectAttributes.addFlashAttribute("name", name);
        redirectAttributes.addFlashAttribute("username", username);

        return "redirect:/success";
    }

    @GetMapping("/success")
    public String success() {
        return "success";
    }

    @GetMapping("/welcome")
    public String welcome(@ModelAttribute("username") String username, Model model) {
        model.addAttribute("username", username);
        return "welcome";
    }

    @GetMapping("/edit")
    public String editProfile() {
        return "edit";
    }

    @PostMapping("/update")
    public String updateUser(@RequestParam("username") String username,
                             @RequestParam("name") String name,
                             @RequestParam("password") String password,
                             RedirectAttributes redirectAttributes) {

        userRepository.updateUser(username, name, password);
        redirectAttributes.addFlashAttribute("username", username);
        redirectAttributes.addFlashAttribute("message", "Profile updated successfully!");
        return "redirect:/welcome";
    }

    @GetMapping("/logout")
    public String logout() {
        return "redirect:/login";
    }
}
